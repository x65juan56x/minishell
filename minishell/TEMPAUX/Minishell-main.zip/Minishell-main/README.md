# Minishell 
#### Made by Vigorate (Amine Belkacem) & JCluzet
## Compatible LINUX & MacOS (need to remove rl_replace_line from srcs/signal/manage_signal.c) 101% ✅
### This project teaches how to recreate a bash

The project consists in making X Philosophers live at the same time as a thread, each one has to eat, think and sleep.

📌 Read subject in the repo for the subject of this 42 project.

## How to test Minishell 🗺 :

You need to make first.
Then run ./minishell without arguments.

## How to launch ?

Just do ./make
and execute with ./minishell

This project is conform with Norminette 3.3.2 📌

👋🏼 If you encounter any problems when launching the program or if you have any questions, don't hesitate to send me an e-mail : jcluzet@student.42.fr 
